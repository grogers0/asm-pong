README.TXT wmh 9/25/02 -- tools and information for the 16bit x86 assembly/C compilation process

Index to contents of this directory
\16bitx86			--root directory.  For .bat files and PATH info to work, this must be at C:\
\16bitx86\16bitx86.PIF	--put this on your desktop to start in the .\work directory with PATH info set
\16bitx86\nasm		--nasm executables, some doc, and nasmide (not tried)
\16bitx86\tc		--Borland TurboC++ 1.01 (1990), minimal doc, include files and libraries
\16bitx86\util		--so far only bin2hex (later, some decent editor, other conversion utils)
\16bitx86\util\exeinfo	--work in progress.  Will be a utility for converting .EXE files to .HEX files for the P14
\16bitx86\work		--where you should put your code development directories
\16bitx86\work\local.BAT	--runs from 16bitx86.PIF above; sets paths for nasm, TurboC
\16bitx86\work\casm16	--sample mixed assembly+C example with example  .BAT files for making different versions
\16bitx86\work\casm16\casm16a.ASM	--sample nasm function definitions to be called by/call C functions
\16bitx86\work\casm16\casm16c.C		--sample C function definitions and MAIN to call/be called by nasm functions
\16bitx86\work\casm16\makecomt.BAT	--assembles, compiles and links a .COM file from casm16a.ASM+casm16c.C
\16bitx86\work\casm16\makecomd.BAT	--assembles, compiles, links and debugs a .COM file from casm16a.ASM+casm16c.C
\16bitx86\work\casm16\makeexes.BAT	--assembles, compiles and links a .EXE file from casm16a.ASM+casm16c.C
\16bitx86\work\casm16\makeexed.BAT	--assembles, compiles, links and debugs a .EXE file from casm16a.ASM+casm16c.C

Installation instructions
1) unzip the file so all paths begin at root of drive C:, e.g. C:\16bitx86\etc. (o.w. you'll have to edit all the bats and pifs)
2a) (W98) copy \16bitx86\16bitx86.PIF to your desktop 
2b) (NT4) copy \16bitx86\NT16bitx86.LNK to your desktop 
3) click icon from 2a/b to open a DOS window, set PATH, etc.  You end up at the DOS prompt in .\work
4) type> 'cd casm16' to move into the demo directory
5) type> 'makecomt' then 'casm16t' to test assembly and execution of the .COM demo version
6) type> 'makeexes' then 'casm16s' to test assembly and execution of the .EXE demo version
7) type> 'makecomd' then answer 'Y'  to test assembly and debug of the .COM debug demo version
   (in NT the Y/N query function doesn't work--type> 'td casm16d.com' to start debugging)
8) type> 'makeexed' then answer 'Y'  to test assembly and debug of the .EXE debug demo version
   (in NT the Y/N query function doesn't work--type> 'td casm16d.exe' to start debugging)



	