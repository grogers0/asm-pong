/*casm16c.c wmh 04/10/02 shell to call casm16a.asm
//Code demos showing djgpp/nasm procedure calling conventions
//(information from Dr. Paul Carters text)
//First assemble casm16a.asm with "nasm -f obj casm16.asm" where nasm is ver 0.98, 
// then compile with "tcc casm16a.obj casm16c.c"  where tcc is Borland TurboC v1.0 (1990)
/  to get casm16a.exe
*/
#include <stdlib.h>
#include <stdio.h>

int vasmproc(int);      /*/example call-by-value nasm procedure */
int v2asmproc(int,int); /*/example call-by-2nd-argument-value nasm procedure*/
int rasmproc(int *);    /*/example call-by-reference nasm procedure*/
int rmodproc(int *);    /*/example call-by-reference to modify source value*/
int callcproc(int,int); /*/example asm-calling-c-procedure*/

int main(void)
{
    int i=123;
    int j=456;
    int k;
    printf("\n\n\n vasmproc call-by-value result: %d",vasmproc(i));
    printf("\n v2asmproc call-by-2nd-value result: %d",v2asmproc(i,j));
    printf("\n rasmproc call-by-reference result: %d",rasmproc(&i));
    rmodproc(&i);   /*/asm routine modifies 'i' directly*/
    printf("\n rmodproc modify-at-reference result: %d",i);
    k=callcproc(i,j);
    printf("\n after the roundtrip through callcproc/cproc, result is %d",k);
    printf("\n");
    return 0;
}

int cproc(int x)
{
    printf("\n cproc received %d from callcproc",x);
    return x+1;
}
