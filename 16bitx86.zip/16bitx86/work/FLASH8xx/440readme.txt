440readme.txt wmh 10/29/03 -- about P14x FLASH programming

-If your P14x board has the PSD813F2 chip, run 'FLASH813 p14xdemo' from a DOS prompt.
-If your P14x board has the PSD833F2 chip, run 'FLASH833 p14xdemo' from a DOS prompt.
-There is information in the .bat files about the necessary conditions (configuration jumper, required files) 
 for FLASH programming to work as well as information allowing you to customize your things to your own taste.
-P14xdemo.asm shows use of several interrupts as well as the displays.   