 readme_mainCOM.txt

The file files in this .zip are a set of assembly language sources which are to be assembled and linked with the included .bat file. The resulting file mainCOM.com can be executed to illustrate an assembly language 'main' program calling several externally defined assembly language functions.

Note that there is a new utility chop512.com included in this .zip file which must be on the path set by makeCOM.bat. The default location for this file is in c:\16bitx86\util. 

When demoing the assembly language program, hit 'space' to start the action, then hit various keys, then hit 'space' again to quit. This works everywhere but on my IBM laptop, where it doesn't work at all. 

The files 'beginCOM.asm' and 'endCOM.asm' contain startup code which allows the assembly language 'main' and its functions to run in a PC environment.