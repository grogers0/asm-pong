/* colltest.c - GRR - 10/31/06
 * Test program to drive the collision detection module
 *
 */

#include <stdio.h>

int radius=3;		/* radius of ball in pixels */
int width=5;		/* width of paddle in pixels */
int height=20;		/* height of paddle in pixels */

int collision(int x_paddle, int y_paddle, int width_paddle, int height_paddle,
			int x_ball, int y_ball, int radius_ball);

/* call program with arguments like:
 * 		colltest.com x_paddle y_paddle x_ball y_ball
 * where x_paddle and y_paddle specify the (x,y) coords of the paddle's top
 * left corner. x_ball and y_ball specify the (x,y) coords of the center of
 * the ball.
 */  
 
int main(int argc, char **argv)
{
	int x_ball, y_ball, x_paddle, y_paddle, collided;

	/* error test the inputs */
	if( argc != 5 )
	{
		printf("USAGE:\n\tcolltest.com xpaddle ypaddle xball yball\n");
		exit(1);
	}

	x_paddle = atoi(argv[1]);
	y_paddle = atoi(argv[2]);
	x_ball = atoi(argv[3]);
	y_ball = atoi(argv[4]);
	
	collided = collision( x_paddle, y_paddle, width, height, 
						 x_ball, y_ball, radius);
	
//	printf("Paddle width: %d\n", width);
//	printf("Paddle height: %d\n", height);
//	printf("Ball radius: %d\n", radius);
//	printf("Paddle position: (%d,%d)\n", x_paddle, y_paddle);
//	printf("Ball position: (%d,%d)\n", x_ball, y_ball);
//	printf("\tCollision? ");
	
	if( collided )
		printf("Yes.\n");
	else
		printf("No.\n");

	return 0;
}
