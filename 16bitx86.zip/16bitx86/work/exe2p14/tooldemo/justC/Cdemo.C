//Cdemo.C wmh 03/08/04 demo using startp14.obj 

//external functions built into startP14.obj
void showhex(int);  		//primitive hex display -- does one refresh cycle and returns
int queryswitches(void);	//primitive switch scan -- returns number 1-12 of first switch detected or 0

int main(void)
{
 int i,displayvalue;	 //automatic variables, starting value = 0

 while(1) //forever
 {
  	while((i=queryswitches())==0) showhex(displayvalue); //display value while waiting for switch
	displayvalue=(16*displayvalue) + i;
	while(queryswitches()!=0) showhex(displayvalue); 	 //display value while waiting for switch release
 }
 
} 
 
