readme_exe2p14_tooldemo_support.txt wmh 03/10/04 contents of the support directory
	p14xu411.jed					--	programming file of P14x U4 logic
	P14xU411_SCH_1-4.pdf			--  logic design schematics for ""
	DECAP.EXE						--  file preparation utility to be placed in C:\16bitx86\util
	KNEECAP.EXE						--  converts P14x .exe file into PC-debuggable .exe (requires different STARTxx.obj, not provided)
	
	