readme_exe2P14_tooldemo.txt wmh 03/10/04 programming demonstrations for P14xnx71.pcb 

The directories \justasm and \justC contain programming examples 'asmdemo.asm' and
'cdemo.c' of programs written for the P14xnx71.pcb version of the P14x board. These
programs can be assembled/compiled and downloaded to the P14x by running the batch 
files 'burnROM.bat' in each directory. 

The following conditions must be met:

	1) A P14x with the PSD833F2 FLASH ROM must be attached by parallel cable to a PC printer port and powered up;

	2) jumper 'CFG1' (between U2 and U4) on the P14x must be installed;

	3) FLINK (currently here: http://www.st.com/stonline/products/families/memories/psm/support/upfl0930.zip )
	must have been installed in the default location on the PC. 

	4) For Windows NT/2000/XP, Tomas Franzon's 'USERPORT' utility 
	(currently here: http://www.embeddedtronics.com/public/Electronics/minidaq/userport/UserPort.zip ) 
	must be installed to permit FLINK to get at the parallel port. 
	(Don't forget to place 'USERPORT.sys' in the appropriate Windows system directory as called for by the documentation.)

	5) In addition to the assembler, compiler, linker and other programs in 16bitx86, the file preparation utilities
	BIN2HEX.EX and DECAP.EXE must be on the path in c:\16bitx86\util; 

	6) In addition to the source program, the following files MUST be in the default directory (e.g. where 
	'burnROM' is run):
	   - startP14.obj
	   - P14xu2u3.pre
	   - 833u203.pst
	   - 833ROM.jcf 
	  Optionally, you may provide the additional files
	   -FS4.hex, FS5.hex, FS6.hex	   
	  which may contain additional data, code, etc in intel hex ascii format. See the included example files.
	  
After 'burnROM' is run, you may be interested in the .map and .lst map and list files of the assembly/compile. 

Other notes:
	  1) The startup code in in the current version of STARTP14.obj starts your program (which will be located
	  in P14x ROM at FC00:0) with initial conditions:
	  	   CS:IP=0xFC00:_main (that is, wherever your global label '_main' is in the .asm version, or at main() in .c) 
		   DS=ES=SS=0x20	  (at physical address 0x200)
		   SP=0x600			  (this would be the top of P14x RAM for the 2K RAM version of the PSD chip, but since you have
		   					  the PSD833F2 chip with 8K of RAM, there is another 6K or RAM 'above' the stack.)

	  2) If you are attempting to load a Xilinx programming file to U3 (XC5202), then your flash page 4 (FS4.hex)
	  file will contain the .mcx bit file (edited .mcs bit file) output from the Xilinx logic development tools.
	  In the case where FS4.hex is a correctly formatted .mcx file, the startup displays will show '2..P..' for several
	  seconds before your program starts, else '0' (if no/misformatted .mcx file is present, '1','3' (some hardware 
	  problem on the board or chip). 

	  3) To confirm that your data/code made it to ROM, holding down switches 1/2/3/4 on the P14x while pressing/releasing
	  reset will show the first two bytes of data stored in ROM on flash pages FS4 (Xilinx bit file) ,FS5,FS6,FS7 (your program)
	  as a hex word (don't forget, it will displaying the little-endian value). 	

	  4) There are several functions in startP14.obj which are callable from your application:
	  	 extern _queryswitches ( int _queryswitches(void) : query switches 1-12, return switch value or 0 )
		 extern _showhex	 ( void _showhex(int) : display the word in ax as 4 hex digits )
	  These may be called directly in C or by using C calling conventions, from assembly (see the examples). 

	  5) There are several hardware initializations (of '188 timers, interrupts, etc.) performed by various
	  startup routines which are not documented here as their definitions are not yet stable (watch this space). 
 			  
		   
		    
	  
	  

